import React, { useEffect, useMemo, useState } from 'react';
import AuthScreen from './components/AuthScreen';
import TaskScreen from './components/TaskScreen';
import TasksScreen from './components/TasksScreen';
import ProfileScreen from './components/ProfileScreen';
import {
  defaultUser,
  formatDate,
  getSignedInLabel,
  getTodayLocalISO,
  readJSON,
  STORAGE_TASKS,
  STORAGE_USER,
  writeJSON,
} from './utils/storage';

const defaultSignIn = { email: '', password: '' };
const defaultCreate = { name: '', email: '', phone: '', gender: '', dob: '', password: '', confirmPassword: '' };
const defaultTask = { title: '', description: '', date: '', category: '', highPriority: false, priorityDescription: '' };

export default function App() {
  const [screen, setScreen] = useState('auth');
  const [authMode, setAuthMode] = useState('signin');
  const [user, setUser] = useState(() => readJSON(STORAGE_USER, defaultUser));
  const [hasSavedUser, setHasSavedUser] = useState(() => Boolean(window.localStorage.getItem(STORAGE_USER)));
  const [tasks, setTasks] = useState(() => readJSON(STORAGE_TASKS, []));
  const [signInData, setSignInData] = useState(defaultSignIn);
  const [createData, setCreateData] = useState(defaultCreate);
  const [taskForm, setTaskForm] = useState(defaultTask);
  const [profileReturnScreen, setProfileReturnScreen] = useState('projects');
  const [signedInLabel, setSignedInLabel] = useState('student');
  const [passwordVisibility, setPasswordVisibility] = useState({ signin: false, create: false, confirm: false });

  useEffect(() => {
    writeJSON(STORAGE_TASKS, tasks);
  }, [tasks]);

  useEffect(() => {
    if (hasSavedUser) {
      writeJSON(STORAGE_USER, user);
    }
  }, [user, hasSavedUser]);

  const todayMin = useMemo(() => getTodayLocalISO(), []);

  const handleAuthModeChange = (mode) => setAuthMode(mode);

  const handleSignInChange = (field, value) => {
    setSignInData((prev) => ({ ...prev, [field]: value }));
  };

  const handleCreateChange = (field, value) => {
    setCreateData((prev) => ({ ...prev, [field]: value }));
  };

  const handleTaskChange = (field, value) => {
    setTaskForm((prev) => ({ ...prev, [field]: value }));
  };

  const togglePassword = (field) => {
    setPasswordVisibility((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const goToSignIn = () => {
    setAuthMode('signin');
    setScreen('auth');
  };

  const handleCreateSubmit = (event) => {
    event.preventDefault();
    if (createData.password !== createData.confirmPassword) {
      window.alert('Passwords do not match.');
      return;
    }

    const nextUser = {
      name: createData.name.trim(),
      email: createData.email.trim(),
      phone: createData.phone.trim(),
      gender: createData.gender,
      dob: createData.dob,
      password: createData.password,
    };

    setUser(nextUser);
    setHasSavedUser(true);
    setSignInData({ email: nextUser.email, password: nextUser.password });
    setCreateData(defaultCreate);
    window.alert('Account created successfully. Please sign in.');
    goToSignIn();
  };

  const handleSignInSubmit = (event) => {
    event.preventDefault();
    const email = signInData.email.trim();
    const password = signInData.password.trim();

    if (!email || !password) {
      window.alert('Please enter your email and password.');
      return;
    }

    const canSignIn = !hasSavedUser || ((email === user.email || email === user.name) && password === user.password);
    if (!canSignIn) {
      window.alert('Please use the account details from Create Account.');
      return;
    }

    setSignedInLabel(getSignedInLabel(email));
    setScreen('task');
  };

  const handleResetTask = () => setTaskForm(defaultTask);

  const handleSubmitTask = (event) => {
    event.preventDefault();
    if (taskForm.date && taskForm.date < todayMin) {
      window.alert('Please select today or a future date only.');
      return;
    }

    if (taskForm.highPriority && !taskForm.priorityDescription.trim()) {
      window.alert('Please explain why this task is urgent.');
      return;
    }

    const nextTask = {
      title: taskForm.title.trim(),
      category: taskForm.category,
      priority: taskForm.highPriority ? 'High' : 'Low',
      date: taskForm.date,
      description: taskForm.description.trim(),
      priorityDescription: taskForm.priorityDescription.trim(),
      createdAt: formatDate(todayMin),
    };

    setTasks((prev) => [...prev, nextTask]);
    setTaskForm(defaultTask);
    setScreen('projects');
  };

  const handleDeleteTask = (index) => {
    setTasks((prev) => prev.filter((_, currentIndex) => currentIndex !== index));
  };

  const openProfile = (fromScreen) => {
    setProfileReturnScreen(fromScreen);
    setScreen('profile');
  };

  const handleLogout = () => {
    setSignedInLabel('student');
    goToSignIn();
  };

  return (
    <>
      {screen === 'auth' ? (
        <AuthScreen
          authMode={authMode}
          signInData={signInData}
          createData={createData}
          passwordVisibility={passwordVisibility}
          onAuthModeChange={handleAuthModeChange}
          onSignInChange={handleSignInChange}
          onCreateChange={handleCreateChange}
          onTogglePassword={togglePassword}
          onSignInSubmit={handleSignInSubmit}
          onCreateSubmit={handleCreateSubmit}
        />
      ) : null}

      {screen === 'task' ? (
        <TaskScreen
          signedInLabel={signedInLabel}
          todayMin={todayMin}
          taskForm={taskForm}
          onTaskChange={handleTaskChange}
          onToggleHighPriority={() => setTaskForm((prev) => ({ ...prev, highPriority: !prev.highPriority, priorityDescription: !prev.highPriority ? prev.priorityDescription : '' }))}
          onResetTask={handleResetTask}
          onSubmitTask={handleSubmitTask}
          onBack={goToSignIn}
          onViewTasks={() => setScreen('projects')}
          onLogout={handleLogout}
        />
      ) : null}

      {screen === 'projects' ? (
        <TasksScreen
          tasks={tasks}
          onOpenProfile={() => openProfile('projects')}
          onBack={() => setScreen('task')}
          onDeleteTask={handleDeleteTask}
          onLogout={handleLogout}
        />
      ) : null}

      {screen === 'profile' ? (
        <ProfileScreen
          user={hasSavedUser ? user : { ...defaultUser, email: signInData.email || defaultUser.email }}
          onBack={() => setScreen(profileReturnScreen)}
          onLogout={handleLogout}
        />
      ) : null}
    </>
  );
}

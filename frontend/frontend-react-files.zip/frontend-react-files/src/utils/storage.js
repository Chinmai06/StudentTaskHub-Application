export const STORAGE_USER = 'studentTaskHubUser';
export const STORAGE_TASKS = 'studentTaskHubTasks';

export const defaultUser = {
  name: 'Student User',
  email: 'student@example.com',
  gender: 'Prefer not to say',
  dob: '-',
  phone: '-',
  password: '123456',
};

export function readJSON(key, fallback) {
  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

export function writeJSON(key, value) {
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function getTodayLocalISO() {
  const today = new Date();
  const offset = today.getTimezoneOffset();
  const local = new Date(today.getTime() - offset * 60000);
  return local.toISOString().split('T')[0];
}

export function formatDate(dateStr) {
  if (!dateStr) return '-';
  const date = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function getSignedInLabel(value) {
  if (!value) return 'student';
  return value.includes('@') ? value.split('@')[0] : value;
}

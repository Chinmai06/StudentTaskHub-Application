import React from 'react';

export default function TaskScreen({
  signedInLabel,
  todayMin,
  taskForm,
  onTaskChange,
  onToggleHighPriority,
  onResetTask,
  onSubmitTask,
  onBack,
  onViewTasks,
  onLogout,
}) {
  return (
    <section className="app-screen" id="taskScreen">
      <div className="task-simple-shell">
        <div className="task-simple-topbar">
          <div className="hub-chip">
            <div className="mini-logo">H</div>
            <div className="hub-copy">
              <h3>H-HUB</h3>
              <p>Student Task Hub Dashboard</p>
            </div>
          </div>

          <div className="task-user-actions">
            <div className="signed-pill">Signed in as <span>{signedInLabel}</span></div>
            <button type="button" className="outline-btn task-top-btn" onClick={onLogout}>Log Out</button>
          </div>
        </div>

        <div className="task-simple-card">
          <div className="task-simple-head">
            <div className="task-simple-title">
              <h2>Create New Task</h2>
              <p>Add a task quickly and it will appear in your task list immediately.</p>
            </div>
            <button type="button" className="outline-btn task-top-btn" onClick={onViewTasks}>View Tasks</button>
          </div>

          <form className="task-form stack" onSubmit={onSubmitTask}>
            <div className="field single-wide">
              <label htmlFor="taskTitle">Task Title</label>
              <div className="input-wrap"><input id="taskTitle" type="text" placeholder="eg., Need a ride to campus" required value={taskForm.title} onChange={(e) => onTaskChange('title', e.target.value)} /></div>
            </div>

            <div className="field">
              <label htmlFor="taskDescription">Description</label>
              <div className="input-wrap"><textarea id="taskDescription" placeholder="Add any additional details about this task..." required value={taskForm.description} onChange={(e) => onTaskChange('description', e.target.value)} /></div>
            </div>

            <div className="field-grid split">
              <div className="field">
                <label htmlFor="taskDate">Due Date</label>
                <div className="input-wrap"><input id="taskDate" type="date" min={todayMin} required value={taskForm.date} onChange={(e) => onTaskChange('date', e.target.value)} /></div>
              </div>
              <div className="field">
                <label htmlFor="taskCategory">Category</label>
                <div className="input-wrap">
                  <select id="taskCategory" required value={taskForm.category} onChange={(e) => onTaskChange('category', e.target.value)}>
                    <option value="" disabled>Select</option>
                    <option value="Academic">Academic</option>
                    <option value="Personal">Personal</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="task-toggle-row">
              <div className="toggle-copy">
                <h4>High Priority</h4>
                <p>Turn this on if the task needs urgent attention.</p>
              </div>
              <label className="switch" aria-label="High Priority">
                <input type="checkbox" checked={taskForm.highPriority} onChange={onToggleHighPriority} />
                <span className="switch-track"></span>
              </label>
            </div>

            <div className={`field priority-extra ${taskForm.highPriority ? '' : 'hidden'}`}>
              <label htmlFor="taskPriorityDescription">Priority Description</label>
              <div className="input-wrap"><textarea id="taskPriorityDescription" placeholder="Explain why this task is urgent..." value={taskForm.priorityDescription} onChange={(e) => onTaskChange('priorityDescription', e.target.value)} /></div>
            </div>

            <div className="task-bottom-actions task-action-bar">
              <button type="button" className="secondary-btn ghost-btn" onClick={onBack}>← Back</button>
              <div className="task-submit-actions">
                <button type="button" className="secondary-btn ghost-btn" onClick={onResetTask}>Reset</button>
                <button type="submit" className="primary-btn task-create-btn">+ Create Task</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

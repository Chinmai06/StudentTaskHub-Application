import React from 'react';
import { NotificationsIcon, ProfileIcon, SettingsIcon } from './Icons';

export default function Sidebar({ active = 'profile', onOpenProfile, onLogout }) {
  return (
    <aside className="mini-sidebar">
      <div>
        <div className="mini-brand"><div className="mini-logo">H</div><span>Task Dasher</span></div>
        <div className="mini-menu">
          <button className={`menu-item ${active === 'profile' ? 'active' : ''}`} onClick={onOpenProfile} type="button">
            <ProfileIcon />
            Profile
          </button>
          <button className="menu-item" type="button">
            <NotificationsIcon />
            Notifications <span className="menu-note">2</span>
          </button>
          <button className="menu-item" type="button">
            <SettingsIcon />
            Settings
          </button>
        </div>
      </div>
      <button className="secondary-btn" onClick={onLogout} type="button">Log out</button>
    </aside>
  );
}

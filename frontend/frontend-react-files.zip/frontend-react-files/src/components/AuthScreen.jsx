import React from 'react';
import { EyeIcon } from './Icons';

export default function AuthScreen({
  authMode,
  signInData,
  createData,
  passwordVisibility,
  onAuthModeChange,
  onSignInChange,
  onCreateChange,
  onTogglePassword,
  onSignInSubmit,
  onCreateSubmit,
}) {
  const isSignIn = authMode === 'signin';

  return (
    <section className="app-screen" id="authScreen">
      <div className="center-shell auth-shell">
        <div className="art-panel">
          <div className="brand-pill">
            <div className="mark">H</div>
            <span>Student Task Hub</span>
          </div>
          <div className="art-copy">
            <h1>Welcome<br />back!</h1>
            <p>Sign in to manage student tasks, create new requests, and keep everything organized in one clean workspace.</p>
          </div>
          <div className="feature-pills">
            <span>Task Tracking</span>
            <span>Quick Planning</span>
            <span>My Tasks</span>
          </div>
        </div>

        <div className="form-panel">
          <div className="auth-tabbar">
            <button type="button" className={isSignIn ? 'active' : ''} onClick={() => onAuthModeChange('signin')}>Sign In</button>
            <button type="button" className={!isSignIn ? 'active' : ''} onClick={() => onAuthModeChange('create')}>Create Account</button>
          </div>

          {isSignIn ? (
            <div id="signInView">
              <h2 className="form-title">Sign In</h2>
              <p className="form-subtitle">Use your email and password to continue to H-HUB.</p>
              <form className="stack" onSubmit={onSignInSubmit}>
                <div className="field">
                  <label htmlFor="signinEmail">Username or Email</label>
                  <div className="input-wrap"><input id="signinEmail" type="text" placeholder="you@example.com" required value={signInData.email} onChange={(e) => onSignInChange('email', e.target.value)} /></div>
                </div>
                <div className="field">
                  <label htmlFor="signinPassword">Password</label>
                  <div className="input-wrap">
                    <input id="signinPassword" className="password-input" type={passwordVisibility.signin ? 'text' : 'password'} placeholder="Enter your password" required value={signInData.password} onChange={(e) => onSignInChange('password', e.target.value)} />
                    <button type="button" className="password-toggle" aria-label="Show password" onClick={() => onTogglePassword('signin')}>
                      <EyeIcon />
                    </button>
                  </div>
                </div>
                <div className="helper-row">
                  <label className="checkbox-wrap"><input type="checkbox" defaultChecked /> <span>Remember me</span></label>
                  <button type="button" className="text-link">Forgot password?</button>
                </div>
                <button className="primary-btn" type="submit">Sign In →</button>
              </form>
            </div>
          ) : (
            <div id="createView">
              <h2 className="form-title">Create Account</h2>
              <p className="form-subtitle">Create your account to start using H-HUB.</p>
              <form className="stack" onSubmit={onCreateSubmit}>
                <div className="field">
                  <label htmlFor="fullName">Full Name</label>
                  <div className="input-wrap"><input id="fullName" type="text" placeholder="Enter your full name" required value={createData.name} onChange={(e) => onCreateChange('name', e.target.value)} /></div>
                </div>
                <div className="field-grid two">
                  <div className="field">
                    <label htmlFor="accountEmail">Username or Email</label>
                    <div className="input-wrap"><input id="accountEmail" type="email" placeholder="you@example.com" required value={createData.email} onChange={(e) => onCreateChange('email', e.target.value)} /></div>
                  </div>
                  <div className="field">
                    <label htmlFor="accountPhone">Phone Number</label>
                    <div className="input-wrap"><input id="accountPhone" type="tel" placeholder="Enter your phone number" required value={createData.phone} onChange={(e) => onCreateChange('phone', e.target.value)} /></div>
                  </div>
                </div>
                <div className="field-grid two">
                  <div className="field">
                    <label htmlFor="accountGender">Gender</label>
                    <div className="input-wrap">
                      <select id="accountGender" required value={createData.gender} onChange={(e) => onCreateChange('gender', e.target.value)}>
                        <option value="" disabled>Select gender</option>
                        <option>Female</option>
                        <option>Male</option>
                        <option>Other</option>
                        <option>Prefer not to say</option>
                      </select>
                    </div>
                  </div>
                  <div className="field">
                    <label htmlFor="accountDob">Date of Birth</label>
                    <div className="input-wrap"><input id="accountDob" type="date" required value={createData.dob} onChange={(e) => onCreateChange('dob', e.target.value)} /></div>
                  </div>
                </div>
                <div className="field">
                  <label htmlFor="accountPassword">Password</label>
                  <div className="input-wrap">
                    <input id="accountPassword" className="password-input" type={passwordVisibility.create ? 'text' : 'password'} placeholder="Enter your password" required value={createData.password} onChange={(e) => onCreateChange('password', e.target.value)} />
                    <button type="button" className="password-toggle" aria-label="Show password" onClick={() => onTogglePassword('create')}>
                      <EyeIcon />
                    </button>
                  </div>
                </div>
                <div className="field">
                  <label htmlFor="confirmPassword">Confirm Password</label>
                  <div className="input-wrap">
                    <input id="confirmPassword" className="password-input" type={passwordVisibility.confirm ? 'text' : 'password'} placeholder="Confirm your password" required value={createData.confirmPassword} onChange={(e) => onCreateChange('confirmPassword', e.target.value)} />
                    <button type="button" className="password-toggle" aria-label="Show password" onClick={() => onTogglePassword('confirm')}>
                      <EyeIcon />
                    </button>
                  </div>
                </div>
                <button className="primary-btn" type="submit">Create Account →</button>
              </form>
              <p className="switch-copy">Already have an account? Switch back to Sign In.</p>
              <div className="create-actions">
                <button type="button" className="outline-btn" onClick={() => onAuthModeChange('signin')}>Sign In</button>
                <button type="button" className="secondary-btn small-back-btn" onClick={() => onAuthModeChange('signin')}>← Back</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

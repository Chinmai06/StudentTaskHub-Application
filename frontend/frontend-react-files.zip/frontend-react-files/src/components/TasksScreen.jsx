import React from 'react';
import Sidebar from './Sidebar';
import { formatDate } from '../utils/storage';

export default function TasksScreen({ tasks, onOpenProfile, onBack, onDeleteTask, onLogout }) {
  return (
    <section className="app-screen" id="projectsScreen">
      <div className="center-shell app-shell">
        <Sidebar active="none" onOpenProfile={onOpenProfile} onLogout={onLogout} />

        <main className="page-wrap">
          <div className="page-header">
            <div className="page-title">
              <h2>Tasks</h2>
              <p>All created tasks will be listed here.</p>
            </div>
            <div className="badge"><span>{tasks.length}</span> tasks</div>
          </div>

          <div className="content-card tasks-table-wrap">
            {!tasks.length ? (
              <div className="table-empty">No tasks yet. Create your first task and it will appear here.</div>
            ) : (
              <table className="tasks-table">
                <thead>
                  <tr>
                    <th>Task</th>
                    <th>Category</th>
                    <th>Priority</th>
                    <th>Due Date</th>
                    <th>Description</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((task, index) => (
                    <tr key={`${task.title}-${index}`}>
                      <td><strong>{task.title}</strong></td>
                      <td><span className={`pill ${String(task.category || '').toLowerCase()}`}>{task.category}</span></td>
                      <td><span className={`pill ${String(task.priority || '').toLowerCase()}`}>{task.priority}</span></td>
                      <td>{formatDate(task.date)}</td>
                      <td>
                        {task.description}
                        {task.priorityDescription ? <div className="priority-note-line"><strong>Urgent:</strong> {task.priorityDescription}</div> : null}
                      </td>
                      <td><button className="text-link" type="button" onClick={() => onDeleteTask(index)}>Delete</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div className="back-corner">
              <button className="fab" onClick={onBack} type="button">← Back</button>
            </div>
          </div>
        </main>
      </div>
    </section>
  );
}

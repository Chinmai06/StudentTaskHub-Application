import React from 'react';
import Sidebar from './Sidebar';

export default function ProfileScreen({ user, onBack, onLogout }) {
  return (
    <section className="app-screen" id="profileScreen">
      <div className="center-shell app-shell">
        <Sidebar active="profile" onOpenProfile={() => {}} onLogout={onLogout} />

        <main className="page-wrap">
          <div className="page-header">
            <div className="page-title">
              <h2>Profile</h2>
              <p>Your account details saved from the create account page.</p>
            </div>
            <div className="badge">Student</div>
          </div>

          <div className="profile-shell">
            <div className="profile-hero">
              <button className="back-mini" onClick={onBack} type="button">←</button>
              <div className="avatar">🙂</div>
              <h3>{user.name || 'Student Name'}</h3>
              <p>{user.email || 'student@example.com'}</p>
            </div>

            <div className="profile-card">
              <div className="detail-row"><span>Name</span><span>{user.name || '-'}</span></div>
              <div className="detail-row"><span>Email</span><span>{user.email || '-'}</span></div>
              <div className="detail-row"><span>Gender</span><span>{user.gender || '-'}</span></div>
              <div className="detail-row"><span>Date of Birth</span><span>{user.dob || '-'}</span></div>
              <div className="detail-row"><span>Phone Number</span><span>{user.phone || '-'}</span></div>
              <div className="profile-actions">
                <div className="action-card">Change Password</div>
                <div className="action-card">My Orders</div>
                <div className="action-card">Help</div>
              </div>
              <div className="back-corner">
                <button className="fab" onClick={onBack} type="button">← Back</button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </section>
  );
}
